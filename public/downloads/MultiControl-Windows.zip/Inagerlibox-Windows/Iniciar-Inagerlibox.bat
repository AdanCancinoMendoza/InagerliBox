@echo off
title Inagerlibox - Xbox Hub
echo ===================================================
echo     Iniciando Inagerlibox en Segundo Plano...
echo ===================================================
start /B node server/relay-server.js
timeout /t 1 /nobreak >nul
start http://localhost:5174/
exit
