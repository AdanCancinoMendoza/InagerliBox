@echo off
title Instalador Inagerlibox Windows
echo ===================================================
echo Agregando Inagerlibox a Inicio de Windows...
echo ===================================================
set SCRIPT="%TEMP%\%RANDOM%-%RANDOM%_shortcut.vbs"
echo Set oWS = WScript.CreateObject("WScript.Shell") >> %SCRIPT%
echo sLinkFile = "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Inagerlibox.lnk" >> %SCRIPT%
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> %SCRIPT%
echo oLink.TargetPath = "%~dp0Iniciar-Inagerlibox.bat" >> %SCRIPT%
echo oLink.WorkingDirectory = "%~dp0" >> %SCRIPT%
echo oLink.Save >> %SCRIPT%
cscript /nologo %SCRIPT%
del %SCRIPT%
echo.
echo [OK] Inagerlibox iniciara automaticamente al encender tu PC!
echo.
pause
