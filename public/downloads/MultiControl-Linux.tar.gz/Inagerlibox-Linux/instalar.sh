#!/bin/bash
set -e
echo "=========================================================="
echo "    Inagerlibox: Instalador de Aplicación y Servicio      "
echo "=========================================================="
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NODE_BIN="$(which node || echo "/usr/bin/node")"

mkdir -p "$HOME/.config/systemd/user"
cat <<UNIT > "$HOME/.config/systemd/user/multicontrol.service"
[Unit]
Description=Inagerlibox Xbox Relay Service
After=network.target

[Service]
Type=simple
WorkingDirectory=$DIR
ExecStart=$NODE_BIN server/relay-server.js
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
UNIT

systemctl --user daemon-reload
systemctl --user enable multicontrol.service
systemctl --user restart multicontrol.service

mkdir -p "$HOME/.local/share/applications"
cat <<DESK > "$HOME/.local/share/applications/inagerlibox.desktop"
[Desktop Entry]
Version=1.0
Type=Application
Name=Inagerlibox
GenericName=Xbox Controller Hub
Comment=Juega en tu consola Xbox con cualquier control
Exec=xdg-open http://localhost:5174/
Icon=$DIR/inagerlibox-icon.png
Terminal=false
Categories=Game;Utility;
StartupNotify=true
DESK

chmod +x "$HOME/.local/share/applications/inagerlibox.desktop"
echo "✓ Instalación completada. Ya puedes abrir Inagerlibox desde tu menú de inicio sin usar terminal."
