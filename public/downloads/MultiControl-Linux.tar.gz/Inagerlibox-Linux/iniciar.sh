#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! pgrep -f "server/relay-server.js" > /dev/null; then
  node "$DIR/server/relay-server.js" &
fi
xdg-open http://localhost:5174/ || true
